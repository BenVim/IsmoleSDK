//
//  WebView.h
//  Pay
//
//  Created by Ben on 6/18/13.
//
//

#import <UIKit/UIKit.h>

@interface WebView : UIView

-(void)openWeb:(NSString*) webURL;

-(void)test:(id)sender;

@end
